﻿namespace Ben_Project.Models.AndroidDTOs
{
    public class DeptRequisitionDTONotInUse
    {
        public int Id { get; set; }
        public RequisitionApprovalStatus RequisitionApprovalStatus { get; set; }
        public RequisitionFulfillmentStatus RequisitionFulfillmentStatus { get; set; }
    }
}
