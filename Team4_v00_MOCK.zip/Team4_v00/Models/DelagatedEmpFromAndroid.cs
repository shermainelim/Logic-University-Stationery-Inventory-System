﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ben_Project.Models
{
    public class DelagatedEmpFromAndroid
    {
        public int EmpId { get; set; }
        public String StartDate { get; set; }
        public String EndDate { get; set; }
    }
}
